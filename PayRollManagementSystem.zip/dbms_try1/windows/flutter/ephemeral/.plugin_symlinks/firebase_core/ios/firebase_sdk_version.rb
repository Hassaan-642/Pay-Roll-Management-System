# https://firebase.google.com/support/release-notes/ios
def firebase_sdk_version!()
  '10.7.0'
end
