import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class InsertScreen extends StatefulWidget {
  const InsertScreen({Key? key}) : super(key: key);

  @override
  State<InsertScreen> createState() => _InsertScreenState();
}

class _InsertScreenState extends State<InsertScreen> {
  TextEditingController deptIdController = TextEditingController();
  TextEditingController empIdController = TextEditingController();
  TextEditingController empNameController = TextEditingController();
  TextEditingController empTitleController = TextEditingController();
  TextEditingController empAddressController = TextEditingController();
  TextEditingController empContactController = TextEditingController();
  TextEditingController empDobController = TextEditingController();
  TextEditingController paymentMethodController = TextEditingController();
  TextEditingController salaryController = TextEditingController();
  TextEditingController taxController = TextEditingController();
  TextEditingController deleteIdController = TextEditingController();
  DateTime selectedDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insert'),
        backgroundColor: Colors.blue[900], // Navy blue app bar color
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Department ID:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: deptIdController,
            ),
            SizedBox(height: 8.0),
            Text(
              'Employee ID:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: empIdController,
            ),
            SizedBox(height: 8.0),
            Text(
              'Employee Name:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: empNameController,
            ),
            SizedBox(height: 8.0),
            Text(
              'Employee Title:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: empTitleController,
            ),
            SizedBox(height: 8.0),
            Text(
              'Employee Address:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: empAddressController,
            ),
            SizedBox(height: 8.0),
            Text(
              'Employee Contact Info:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: empContactController,
            ),
            SizedBox(height: 8.0),
            Text(
              'Employee DOB:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            GestureDetector(
              onTap: () async {
                final DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime.now(),
                );

                if (pickedDate != null) {
                  setState(() {
                    selectedDate =
                        pickedDate; // Store the selected date in a DateTime object
                  });
                }
              },
              child: Container(
                padding: EdgeInsets.all(10.0), // Add padding to the container
                decoration: BoxDecoration(
                  color: Colors.blue, // Add a background color
                  borderRadius:
                      BorderRadius.circular(8.0), // Add rounded corners
                ),
                child: Text(
                  selectedDate != null
                      ? DateFormat('yyyy-MM-dd').format(selectedDate)
                      : 'Select Date',
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.white, // Add text color
                  ),
                ),
              ),
            ),
            SizedBox(height: 8.0),
            Text(
              'Payment Method:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: paymentMethodController,
            ),
            SizedBox(height: 8.0),
            Text(
              'Salary:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: salaryController,
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 8.0),
            Text(
              'Tax:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: taxController,
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                // Save the entered values
                final String deptId = deptIdController.text;
                final String empId = empIdController.text;
                final String empName = empNameController.text;
                final String empTitle = empTitleController.text;
                final String empAddress = empAddressController.text;
                final String empContact = empContactController.text;
                final String paymentMethod = paymentMethodController.text;
                final double salary =
                    double.tryParse(salaryController.text) ?? 0.0;
                final double tax = double.tryParse(taxController.text) ?? 0.0;

                // Check if any field is left empty
                if (deptId.isEmpty ||
                    empId.isEmpty ||
                    empName.isEmpty ||
                    empTitle.isEmpty ||
                    empAddress.isEmpty ||
                    empContact.isEmpty ||
                    paymentMethod.isEmpty ||
                    salaryController.text.isEmpty ||
                    taxController.text.isEmpty) {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content: Text('No field can be left empty.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                  return; // Stop further execution
                }

                // Perform the insertion logic here
                final db = FirebaseFirestore.instance;

                // Perform the query to check uniqueness
                try {
                  final QuerySnapshot querySnapshot =
                      await db.collection("Departments").get();

                  for (final QueryDocumentSnapshot documentSnapshot
                      in querySnapshot.docs) {
                    final List<dynamic> employees = (documentSnapshot.data()
                        as Map<String, dynamic>)['employees'];

                    for (final dynamic employee in employees) {
                      final String empIdInArray = employee['emp_id'];

                      if (empIdInArray == empId) {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: Text('Error'),
                            content: Text('Employee ID already exists.'),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context); // Close the dialog
                                },
                                child: Text('OK'),
                              ),
                            ],
                          ),
                        );
                        return; // Stop further execution
                      }
                    }
                  }
                } catch (e) {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content: Text('An error occurred.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                  return; // Stop further execution
                }

                // If no existing employee ID found, proceed with insertion logic

                final QuerySnapshot querySnapshot = await db
                    .collection("Departments")
                    .where('dept_id', isEqualTo: deptId)
                    .get();

                if (querySnapshot.docs.isNotEmpty) {
                  // Document with matching dept_id found
                  final DocumentSnapshot documentSnapshot =
                      querySnapshot.docs[0];
                  final Map<String, dynamic> documentData =
                      documentSnapshot.data() as Map<String, dynamic>;

                  // Update the "employees" array
                  final List<dynamic> employees =
                      documentData['employees'] ?? [];
                  final Map<String, dynamic> user = {
                    "emp_id": empId,
                    "emp_name": empName,
                    "emp_title": empTitle,
                    "emp_address": empAddress,
                    "emp_contact": empContact,
                    "emp_dob": Timestamp.fromDate(selectedDate),
                    "payment_method": paymentMethod,
                    "salary": salary,
                    "tax": tax,
                  };
                  employees.add(user);

                  // Update the document in Firestore
                  await documentSnapshot.reference
                      .update({'employees': employees});

                  print('Employee data inserted successfully');

                  // Show a dialog or navigate to another screen
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Insert Successful'),
                      content: Text('Data has been inserted.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                            // You can navigate to another screen here if needed.
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                } else {
                  // No document found with matching dept_id
                  print('No department found with the provided ID');

                  // Show a dialog or handle the error
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content:
                          Text('No department found with the provided ID.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                }
              },
              child: Text('Insert'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Delete button pressed
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Delete Entry'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('Enter the ID to delete:'),
                        SizedBox(height: 8.0),
                        TextField(
                          controller: deleteIdController,
                        ),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () async {
                          final String idToDelete = deleteIdController.text;

                          // Perform the deletion logic here
                          var db = FirebaseFirestore.instance;
                          bool idFound = false;

                          try {
                            CollectionReference departmentsRef = db.collection('Departments');
                            QuerySnapshot querySnapshot = await departmentsRef.get();

                            if (querySnapshot.docs.isNotEmpty) {
                              // Iterate over each document in the collection
                              for (DocumentSnapshot documentSnapshot in querySnapshot.docs) {
                                Map<String, dynamic> data = documentSnapshot.data() as Map<String, dynamic>;

                                if (data != null) {
                                  List<dynamic> employees = data['employees'];

                                  // Find the index of the object with matching "emp_id" in the "employees" array
                                  int indexToDelete = -1;
                                  for (int i = 0; i < employees.length; i++) {
                                    if (employees[i]['emp_id'] == idToDelete) {
                                      indexToDelete = i;
                                      break;
                                    }
                                  }

                                  if (indexToDelete != -1) {
                                    // Remove the object from the "employees" array
                                    employees.removeAt(indexToDelete);

                                    // Update the document with the modified "employees" array
                                    await documentSnapshot.reference.update({'employees': employees});

                                    idFound = true;

                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          title: Text('Employee Deleted'),
                                          content: Text('Employee information has been deleted.'),
                                          actions: [
                                            TextButton(
                                              child: Text('OK'),
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                              },
                                            ),
                                          ],
                                        );
                                      },
                                    );

                                    print('Object with emp_id $idToDelete deleted from ${documentSnapshot.id}');
                                    break; // Exit the loop since the ID was found
                                  }
                                } else {
                                  print('No data found in ${documentSnapshot.id}');
                                }
                              }

                              if (!idFound) {
                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      title: Text('Employee Not Found'),
                                      content: Text('No employee with the specified ID was found.'),
                                      actions: [
                                        TextButton(
                                          child: Text('OK'),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ],
                                    );
                                  },
                                );

                                print('No object with emp_id $idToDelete found in any document');
                              }
                            } else {
                              print('No documents found in the "Departments" collection.');
                            }
                          } catch (e) {
                            print(e);
                          }
                        },
                        child: Text('Delete'),
                      ),
                    ],
                  ),
                );
              },
              child: Text('Delete'),
            ),
          ],
        ),
      ),
    );
  }
}
