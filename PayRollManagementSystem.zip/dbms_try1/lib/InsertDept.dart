import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'Utility/route.dart';

class InsertDeptScreen extends StatefulWidget {
  const InsertDeptScreen({Key? key}) : super(key: key);

  @override
  State<InsertDeptScreen> createState() => _InsertDeptScreenState();
}

class _InsertDeptScreenState extends State<InsertDeptScreen> {
  TextEditingController deptIdController = TextEditingController();
  TextEditingController deptNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insert Department'),
        backgroundColor: Colors.blue[900], // Navy blue app bar color
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Department ID:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: deptIdController,
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            Text(
              'Department Name:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: deptNameController,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                // Insert button pressed
                // Save the entered values
                final String deptId = deptIdController.text;
                final String deptName = deptNameController.text;

                // Check if any field is left empty
                if (deptId.isEmpty || deptName.isEmpty) {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content: Text('No field can be left empty.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                  return; // Stop further execution
                }

                // Perform the insertion logic here
                var db = FirebaseFirestore.instance;

                // Check if the deptId already exists in the collection
                final querySnapshot = await db
                    .collection('Departments')
                    .where('dept_id', isEqualTo: deptId)
                    .get();

                if (querySnapshot.docs.isNotEmpty) {
                  // Department with the same deptId already exists
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content:
                          Text('Department with the same ID already exists.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                  return; // Stop further execution
                }

                final user = <String, dynamic>{
                  "dept_id": deptId,
                  "dept_name": deptName,
                  "employees": [],
                };

                final userDocRef = await db.collection("Departments").add(user);
                final userDocId = userDocRef.id;

                // Show a dialog or navigate to another screen
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Insert Successful'),
                    content: Text('Department has been inserted.'),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context); // Close the dialog
                          // You can navigate to another screen here if needed.
                        },
                        child: Text('OK'),
                      ),
                    ],
                  ),
                );
              },
              child: Text('Insert'),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, RoutesName.options);
                // Navigate to Ins/Del Employee screen
              },
              child: Text('Return to Options'),
            ),
          ],
        ),
      ),
    );
  }
}
