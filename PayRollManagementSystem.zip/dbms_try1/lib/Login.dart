import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../Utility/route.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _errorText = ''; // New variable to hold error text

  void _signInWithEmailAndPassword() async {
    try {
      final String email = _emailController.text.trim();
      final String password = _passwordController.text.trim();

      if (email.isEmpty || password.isEmpty) {
        // Handle case where email or password is empty
        return;
      }

      UserCredential userCredential =
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Successfully signed in, navigate to the options screen
      Navigator.pushReplacementNamed(context, RoutesName.options);
    } on FirebaseAuthException catch (e) {
      // Handle sign-in errors
      if (e.code == 'invalid-email') {
        // Handle case where user is not found
        setState(() {
          _errorText = 'Incorrect email or password entered.';
        });
      } else if (e.code == 'wrong-password') {
        // Handle case where password is incorrect
        setState(() {
          _errorText = 'Incorrect email or password entered.';
        });
      } else {
        // Handle other error cases
        setState(() {
          _errorText = 'An error occurred. Please try again later.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900], // Navy blue background color
      body: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Login',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 30.0),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Email',
                ),
              ),
              SizedBox(height: 20.0),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,
                  labelText: 'Password',
                ),
              ),
              SizedBox(height: 8.0), // Adjust the size of the SizedBox for error text spacing
              Text(
                _errorText,
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 16.0,
                ),
              ),
              SizedBox(height: 22.0), // Adjust the size of the SizedBox for error text spacing
              ElevatedButton(
                onPressed: _signInWithEmailAndPassword,
                child: Text('Login'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
