import 'package:dbms_try1/Utility/route.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class PersonalScreen extends StatefulWidget {
  final RouteSettings settings;

  const PersonalScreen({
    Key? key,
    required this.settings,
  }) : super(key: key);

  @override
  State<PersonalScreen> createState() => _PersonalScreenState();
}

class _PersonalScreenState extends State<PersonalScreen> {
  @override
  Widget build(BuildContext context) {
    final args = widget.settings.arguments as Map<String, dynamic>?;
    final Map<String, dynamic> selectedDocument = args!['document'].data() as Map<String, dynamic>;
    final int employeeIndex = args['employeeIndex'];

    List<dynamic> employees = selectedDocument['employees'];
    Map<String, dynamic> employeeData = employees[employeeIndex];

    final String fullName = employeeData['emp_name'];
    final String id = employeeData['emp_id'];
    final String dob =
        DateFormat('MMMM d, yyyy').format(employeeData['emp_dob'].toDate());
    final String address = employeeData['emp_address'];

    final double salary = employeeData['salary'] as double;
    final double tax = employeeData['tax'] as double;
    final double netSalary = salary - tax;
    final String departmentId = selectedDocument['dept_id'];
    final String departmentName = selectedDocument['dept_name'];
    final String paymentMethod = employeeData['payment_method'];
    final String empTitle = employeeData['emp_title'];
    final String empContact = employeeData['emp_contact'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Personal Info & PaySlip'),
        backgroundColor: Colors.blue[900], // Navy blue app bar color
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: 16.0),
              Text(
                'Personal Info',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16.0),
              Text(
                'Full Name:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(fullName),
              SizedBox(height: 16.0),
              Text(
                'ID:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(id),
              SizedBox(height: 16.0),
              Text(
                'DOB:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(dob),
              SizedBox(height: 16.0),
              Text(
                'Address:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(address),
              SizedBox(height: 16.0),
              Text(
                'Department ID:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(departmentId),
              SizedBox(height: 16.0),
              Text(
                'Department Name:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(departmentName),
              SizedBox(height: 16.0),
              Text(
                'Employee Title:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(empTitle),
              SizedBox(height: 16.0),
              Text(
                'Payment Method',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(paymentMethod),
              SizedBox(height: 16.0),
              Text(
                'Contact:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(empContact),
              SizedBox(height: 16.0),
              Text(
                'PaySlip',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16.0),
              Text(
                'Salary:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(salary.toString()),
              SizedBox(height: 16.0),
              Text(
                'Tax:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(tax.toString()),
              SizedBox(height: 16.0),
              Text(
                'Net Salary:',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8.0),
              Text(netSalary.toString()),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(
                      context, RoutesName.editInfo,
                      arguments: {
                        'document': args['document'],
                        'employeeIndex': employeeIndex,
                      });
                  // Navigate to Ins/Del Employee screen
                },
                child: Text('Edit Info'),
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, RoutesName.options);
                  // Navigate to Options screen
                },
                child: Text('Return to Options'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
