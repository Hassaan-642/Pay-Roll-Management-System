import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'Utility/route.dart';

class OptionScreen extends StatefulWidget {
  const OptionScreen({Key? key}) : super(key: key);

  @override
  State<OptionScreen> createState() => _OptionScreenState();
}

class _OptionScreenState extends State<OptionScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900], // Navy blue background color
      body: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) {
                      TextEditingController textController =
                          TextEditingController();
                      String errorMessage = '';

                      return AlertDialog(
                        title: Text('Enter User ID'),
                        content: TextField(
                          controller: textController,
                          // Add the TextEditingController
                          decoration: InputDecoration(
                            hintText: 'User ID',
                            errorText: errorMessage.isNotEmpty
                                ? errorMessage
                                : null, // Show error message if present
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () async {
                              String userId = textController.text.trim();

                              var db = FirebaseFirestore.instance;

                              // Perform Firebase query
                              QuerySnapshot querySnapshot =
                                  await FirebaseFirestore.instance
                                      .collection('Departments')
                                      .get();
                              List<QueryDocumentSnapshot> documents =
                                  querySnapshot.docs;
                              bool employeeFound = false;
                              int documentIndex = -1;
                              int employeeIndex = -1;

                              for (int i = 0; i < documents.length; i++) {
                                Map<String, dynamic> selectedDocument =
                                    documents[i].data() as Map<String, dynamic>;
                                List<dynamic> employees =
                                    selectedDocument['employees'];
                                for (int j = 0; j < employees.length; j++) {
                                  Map<String, dynamic> employee = employees[j];
                                  if (employee['emp_id'] == userId) {
                                    employeeFound = true;
                                    documentIndex = i;
                                    employeeIndex = j;
                                    break;
                                  }
                                }
                                if (employeeFound) {
                                  break;
                                }
                              }

                              if (employeeFound) {
                                // Employee found, navigate to the desired screen
                                Navigator.pushNamed(
                                    context, RoutesName.personalInfo,
                                    arguments: {
                                      'document': documents[documentIndex],
                                      'employeeIndex': employeeIndex,
                                    });
                              } else {
                                // Employee not found, display error message
                                Navigator.pop(context); // Close the dialog
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: Text('Employee not found'),
                                    content:
                                        Text('Please enter a valid User ID.'),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(context),
                                        // Close the dialog
                                        child: Text('OK'),
                                      ),
                                    ],
                                  ),
                                );
                              }
                            },
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                },
                child: Text('Search for User ID'),
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, RoutesName.insert);
                  // Navigate to Ins/Del Employee screen
                },
                child: Text('Insert/Delete Employee'),
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, RoutesName.insertdept);
                  // Navigate to Ins/Del Employee screen
                },
                child: Text('Insert Department'),
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, RoutesName.alldetails);
                  // Navigate to Ins/Del Employee screen
                },
                child: Text('All Employee Details and Financial Data'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
