import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PaySlipScreen extends StatefulWidget {
  const PaySlipScreen({Key? key}) : super(key: key);

  @override
  State<PaySlipScreen> createState() => _PaySlipScreenState();
}

class _PaySlipScreenState extends State<PaySlipScreen> {

  final String id = '123456';
  final double netTaxes = 100.0;
  final double totalPay = 500.0;
  final double paidAmount = 300.0;
  final double pendingAmount = 200.0;
  final String lastPayDate = 'May 1, 2023';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PaySlip'),
        backgroundColor: Colors.blue[900], // Navy blue app bar color
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ID:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text(id),
            SizedBox(height: 16.0),
            Text(
              'Net Taxes:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text(netTaxes.toString()),
            SizedBox(height: 16.0),
            Text(
              'Total Pay:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text(totalPay.toString()),
            SizedBox(height: 16.0),
            Text(
              'Paid/Pending:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text('Paid: $paidAmount'),
            SizedBox(height: 4.0),
            Text('Pending: $pendingAmount'),
            SizedBox(height: 16.0),
            Text(
              'Last Pay Cheque Date:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text(lastPayDate),
          ],
        ),
      ),
    );

  }
}