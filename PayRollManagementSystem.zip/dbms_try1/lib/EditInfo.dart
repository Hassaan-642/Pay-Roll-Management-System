import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'Utility/route.dart';

import 'Utility/route.dart';

class EditInfoScreen extends StatefulWidget {
  final RouteSettings settings;

  const EditInfoScreen({
    Key? key,
    required this.settings,
  }) : super(key: key);

  @override
  State<EditInfoScreen> createState() => _EditInfoScreenState();
}

class _EditInfoScreenState extends State<EditInfoScreen> {
  TextEditingController salaryController = TextEditingController();
  TextEditingController taxController = TextEditingController();

  double salary = 0.0;
  double tax = 0.0;
  late String fullName;
  late String id;
  late String dob;
  late String address;
  late String paymentMethod;
  late String empTitle;
  late String empContact;

  @override
  void dispose() {
    salaryController.dispose();
    taxController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    final args = widget.settings.arguments as Map<String, dynamic>?;
    final Map<String, dynamic> selectedDocument = args!['document'].data() as Map<String, dynamic>;
    final int employeeIndex = args['employeeIndex'];

    List<dynamic> employees = selectedDocument['employees'];
    Map<String, dynamic> employeeData = employees[employeeIndex];

    salaryController.text = employeeData['salary'].toString();
    taxController.text = employeeData['tax'].toString();

    // Update the corresponding variables with the initial values
    salary = employeeData['salary'] as double;
    tax = employeeData['tax'] as double;
    fullName = employeeData['emp_name'];
    id = employeeData['emp_id'];
    dob =
    DateFormat('MMMM d, yyyy').format(employeeData['emp_dob'].toDate());
    address = employeeData['emp_address'];
    paymentMethod = employeeData['payment_method'];
    empTitle = employeeData['emp_title'];
    empContact = employeeData['emp_contact'];
  }

  @override
  Widget build(BuildContext context) {
    final args = widget.settings.arguments as Map<String, dynamic>?;
    final Map<String, dynamic> selectedDocument = args!['document'].data() as Map<String, dynamic>;
    final int employeeIndex = args['employeeIndex'];

    List<dynamic> employees = selectedDocument['employees'];
    Map<String, dynamic> employeeData = employees[employeeIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Info'),
        backgroundColor: Colors.blue[900], // Navy blue app bar color
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Increase Salary:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: salaryController,
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  salary = double.tryParse(value) ?? 0.0;
                });
              },
            ),
            SizedBox(height: 16.0),
            Text(
              'Change Taxes:',
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            TextField(
              controller: taxController,
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  tax = double.tryParse(value) ?? 0.0;
                });
              },
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                final FirebaseFirestore firestore = FirebaseFirestore.instance;
                final String departmentId = selectedDocument['dept_id'];
                final String employeeId = employeeData['emp_id'];
                final String documentID = args['document'].id;

                try {
                  DocumentReference documentRef = firestore.collection('Departments').doc(documentID);

                  // Remove the existing employee data from the "employees" array
                  await documentRef.update({
                    'employees': FieldValue.arrayRemove([
                      {
                        'emp_id': employeeId,
                        'emp_name': employeeData['emp_name'],
                        'emp_title': employeeData['emp_title'],
                        'emp_address': employeeData['emp_address'],
                        'emp_contact': employeeData['emp_contact'],
                        'emp_dob': employeeData['emp_dob'],
                        'payment_method': employeeData['payment_method'],
                        'salary': employeeData['salary'],
                        'tax': employeeData['tax'],
                      }
                    ])
                  });

                  // Add the updated employee data to the "employees" array
                  await documentRef.update({
                    'employees': FieldValue.arrayUnion([
                      {
                        "emp_id": id,
                        "emp_name": fullName,
                        "emp_title": empTitle,
                        "emp_address": address,
                        "emp_contact": empContact,
                        "emp_dob": dob,
                        "payment_method": paymentMethod,
                        "salary": salary,
                        "tax": tax,
                      }
                    ])
                  });

                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Info Saved'),
                      content: Text('Changes have been saved.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                } catch (error) {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Error'),
                      content: Text('Failed to update employee data.'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close the dialog
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );
                  print('Error updating employee data: $error');
                }
              },

              child: Text('Save'),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, RoutesName.options);
                // Navigate to Ins/Del Employee screen
              },
              child: Text('Return to Options'),
            ),
          ],
        ),
      ),
    );
  }
}
