import 'package:dbms_try1/Utility/route.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class AllDetailsScreen extends StatefulWidget {
  const AllDetailsScreen({Key? key}) : super(key: key);

  @override
  State<AllDetailsScreen> createState() => _AllDetailsScreenState();
}

class _AllDetailsScreenState extends State<AllDetailsScreen> {
  List<Map<String, dynamic>> allEmployees = [];

  @override
  void initState() {
    super.initState();
    fetchAllEmployees();
  }

  Future<void> fetchAllEmployees() async {
    try {
      List<Map<String, dynamic>> employees = await getAllEmployees() as List<Map<String, dynamic>>;
      setState(() {
        allEmployees = employees;
      });
    } catch (error) {
      print('Error retrieving employees: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Employees and Financial Details'),
        backgroundColor: Colors.blue[900],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: allEmployees.length,
                itemBuilder: (context, index) {
                  Map<String, dynamic> employee = allEmployees[index];
                  String employeeID = employee['emp_id'];
                  String departmentID = employee['dept_id'];
                  String employeeName = employee['emp_name'];
                  String employeeTitle = employee['emp_title'];
                  String employeeSalary = (employee['salary']).toString();
                  String employeeTax = (employee['tax']).toString();

                  return Card(
                    child: ListTile(
                      title: Text(
                        employeeName,
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Employee ID: $employeeID', style: TextStyle(fontSize: 16)),
                          Text('Department ID: $departmentID', style: TextStyle(fontSize: 16)),
                          Text('Employee Title: $employeeTitle', style: TextStyle(fontSize: 16)),
                          Text('Employee Salary: $employeeSalary', style: TextStyle(fontSize: 16)),
                          Text('Employee Tax: $employeeTax', style: TextStyle(fontSize: 16)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.attach_money),
            label: 'Financial Details',
          ),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.pushNamed(context, RoutesName.options);
          } else if (index == 1) {
            showFinancialDetails();
          }
        },
      ),
    );
  }

  void showFinancialDetails() {
    // Calculate gross tax and gross salary paid
    double grossTax = 0;
    double grossSalaryPaid = 0;
    allEmployees.forEach((employee) {
      double tax = employee['tax'];
      double salary = employee['salary'];
      grossTax += tax;
      grossSalaryPaid += salary;
    });

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Financial Details'),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Gross Tax: ${NumberFormat.currency().format(grossTax)}',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Gross Salary Paid: ${NumberFormat.currency().format(grossSalaryPaid)}',
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }
}

Future<List<Map<String, dynamic>>> getAllEmployees() async {
  List<Map<String, dynamic>> allEmployees = [];

  try {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('Departments').get();
    querySnapshot.docs.forEach((documentSnapshot) {
      List<dynamic> employees = ((documentSnapshot.data()) as Map<String, dynamic>)['employees'];
      String departmentID = ((documentSnapshot.data()) as Map<String, dynamic>)['dept_id'];

      employees.forEach((employee) {
        employee['dept_id'] = departmentID; // Add department ID to the employee object
        allEmployees.add(employee);
      });
    });
  } catch (error) {
    print('Error retrieving employees: $error');
  }

  return allEmployees;
}