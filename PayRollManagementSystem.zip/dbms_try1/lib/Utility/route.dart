class RoutesName{
  static const String login = "login";
  static const String options = "options";
  static const String payslip = "paySlip";
  static const String insert = "insert";
  static const String personalInfo = "personal";
  static const String editInfo = "edit";
  static const String insertdept = 'insertdept';
  static const String alldetails = 'alldetails';
}