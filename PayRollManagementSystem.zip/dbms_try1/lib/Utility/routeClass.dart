import '../EditInfo.dart';
import '../InsEmployee.dart';
import '../Login.dart';
import '../Options.dart';
import '../PaySlip.dart';
import '../PersonalInfo.dart';
import '../InsertDept.dart';
import '../AllDetails.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'route.dart';

class Routes {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RoutesName.options:
        return MaterialPageRoute(
            builder: (BuildContext context) => const OptionScreen());

      case RoutesName.login:
        return MaterialPageRoute(
            builder: (BuildContext context) => const LoginScreen());

      case RoutesName.payslip:
        return MaterialPageRoute(
            builder: (BuildContext context) => const PaySlipScreen());

      case RoutesName.editInfo:
        return MaterialPageRoute(
            builder: (BuildContext context) => EditInfoScreen(
              settings: settings,
            ));

      case RoutesName.personalInfo:
        return MaterialPageRoute(
          builder: (BuildContext context) => PersonalScreen(
            settings: settings,
          ),
        );

      case RoutesName.insert:
        return MaterialPageRoute(
            builder: (BuildContext context) => const InsertScreen());

      case RoutesName.insertdept:
        return MaterialPageRoute(
            builder: (BuildContext context) => const InsertDeptScreen());

      case RoutesName.alldetails:
        return MaterialPageRoute(
          builder: (BuildContext context) => AllDetailsScreen());


      default:
        return MaterialPageRoute(builder: (_) {
          return const Scaffold(
            body: Center(
              child: Text("Error 404 Screen Not Found"),
            ),
          );
        });
    }
  }
}
