package com.example.dbms_try1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
