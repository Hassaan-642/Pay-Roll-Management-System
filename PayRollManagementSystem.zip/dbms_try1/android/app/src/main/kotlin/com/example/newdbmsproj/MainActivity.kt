package com.example.newdbmsproj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
